#include "../include/data.h"

struct data{
    int dia;
    int mes;
    int ano;
};

tData* criaData(int dia, int mes, int ano){
    tData *d = (tData*) malloc(sizeof(tData));

    d->dia = dia;
    d->mes = mes;
    d->ano = ano;

    return d;
}

int getDia(tData *data){
    return data->dia;
}

int getMes(tData *data){
    return data->mes;
}

int getAno(tData *data){
    return data->ano;
}

tData* setDia(tData* data, int dia){
    data->dia = dia;
    return data;
}

tData* setMes(tData* data, int mes){
    data->mes = mes;
    return data;
}

tData* setAno(tData* data, int ano){
    data->ano = ano;
    return data;
}