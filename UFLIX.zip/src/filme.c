#include "../include/filme.h"

struct filme{
    char *titulo; // vetor de caracteres
    char *descricao; // vetor de caracteres
    float nota;
    int duracao;
    int ano;
    int id;
};

//lembrar de fazer comentarios