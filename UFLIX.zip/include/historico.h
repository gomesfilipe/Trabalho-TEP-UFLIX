#ifndef HISTORICO_H
#define HISTORICO_H

#include "filme.h"

typedef struct historico tHistorico;

#endif