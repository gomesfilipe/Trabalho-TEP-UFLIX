#ifndef DATA_H
#define DATA_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Para funções toupper e tolower

typedef struct data tData;

tData* criaData(int dia, int mes, int ano);

int getDia(tData *data);

int getMes(tData *data);

int getAno(tData *data);

tData* setDia(tData* data, int dia);

tData* setMes(tData* data, int mes);

tData* setAno(tData* data, int ano);

#endif 