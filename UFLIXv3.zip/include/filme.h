#ifndef FILME_H
#define FILME_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Para funções toupper e tolower

typedef struct filme tFilme;
/**
 * @brief Aloca memória para um tFilme e inicializa seus campos.
 * @param titulo Título do filme.
 * @param descricao Sinopse do filme.
 * @param nota Nota do filme.
 * @param duracao Duração do filme em minutos.
 * @param ano Ano de lançamento do filme.
 * @param id Id do filme, que corresponde a posição dele no arquivo CSV.
 * @return Ponteiro para tFilme inicializado.
 * */
tFilme* criaFilme(char *titulo, char *descricao, float nota, int duracao, int ano, int id);


/**
 * @brief Faz a leitura de todos os filmes presentes no arquivo CSV e os armazena num vetor de ponteiros de filme.
 * @param fileName String que representa o caminho para o arquivo CSV.
 * @return Um vetor de ponteiros de filme inicializado. 
 **/
tFilme** leFilmes(char *fileName);

/**
 * @brief Imprime os dados de um ponteiro para filme.
 * @param filme Filme a ser imprimido.
 **/
void imprimeFilme(tFilme *filme);

/**
 * @brief Imprime os dados de todos os filmes presentes num vetor de ponteiros de filme.
 * @param filmes Vetor de ponteiros de filme.
 * @param tam Tamanho do vetor (quanto de memória foi alocado).
 **/
void imprimeTodosOsFilmes(tFilme **filmes, int tam);

#endif

