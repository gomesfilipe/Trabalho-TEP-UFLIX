#ifndef UTILS_H
#define UTILS_H

/**
 *@brief Conta a quantidade de linhas preenchidas de um arquivo CSV.
 *@param fileName String com caminho até o arquivo CSV.
 *@return Quantidade de linhas preenchidas do arquivo CSV.
 */
int contaLinhasCSV(char *fileName);

#endif