#include "../include/filme.h"
#include "../include/utils.h"

struct filme{
    char *titulo; // vetor de caracteres
    char *descricao; // vetor de caracteres
    float nota;
    int duracao;
    int ano;
    int id;
};

// imprimir filme
// listar filmes
// dar nota ao filme 
// pesquisar filmes
// avançar pagina de filmes
// voltar pagina de filmes

// lembrar de fazer comentarios

//! LEMBRAR DE INVERTER A ORDEM DA DURACAO E ANO DO FILME NAS FUNCOES POIS NO CSV GRANDE TA INVERTIDO

tFilme* criaFilme(char *titulo, char *descricao, float nota, int duracao, int ano, int id){
    tFilme *filme = (tFilme*) malloc(sizeof(tFilme));
    filme->titulo = strdup(titulo); 
    filme->descricao = strdup(descricao);
    filme->nota = nota;
    filme->duracao = duracao;
    filme->ano = ano;
    filme->id = id;

    return filme;
}

tFilme** leFilmes(char *fileName){
    char *titulo = (char*) malloc(sizeof(char) * 128 + 1); 
    char *descricao = (char*) malloc(sizeof(char) * 256 + 1); 
    float nota; 
    int duracao;
    int ano; 
    int id;
    int i = 0;
    
    int qtdFilmes = contaLinhasCSV(fileName);
    FILE *f = fopen(fileName, "r");

    if(f == NULL){
        printf("erro na abertura do arquivo");
        exit(1);
    }
    
    tFilme **filmes = (tFilme**) malloc(sizeof(tFilme*) * qtdFilmes);

    while(!feof(f)){
        fscanf(f, "%[^,],", titulo);
        fscanf(f, "%d,", &duracao);
        fscanf(f, "%d,", &ano);
        fscanf(f, "%f,\"", &nota);
        fscanf(f, "%[^\"]\"\n", descricao);
        id = i;
        
        filmes[i] = criaFilme(titulo, descricao, nota, duracao, ano, id);

        if(feof(f)){
            break;
        }

        i++;
    }

    free(titulo);
    free(descricao);
    fclose(f);
    return filmes;
}

void imprimeFilme(tFilme *filme){
    printf("titulo: %s\n", filme->titulo);
    printf("duracao %d\n", filme->duracao);
    printf("ano: %d\n", filme->ano);
    printf("nota: %.2f\n", filme->nota);
    printf("descricao: %s\n", filme->descricao);
    printf("id: %d\n", filme->id);
    printf("\n");
}

void imprimeTodosOsFilmes(tFilme **filmes, int qtdFilmes){
    for(int i = 0; i < qtdFilmes; i++){
        imprimeFilme(filmes[i]);
    }
}