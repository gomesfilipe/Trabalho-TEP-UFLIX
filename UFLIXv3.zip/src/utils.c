#include <stdio.h>
#include <stdlib.h>
#include "../include/utils.h"

int contaLinhasCSV(char *fileName){
    FILE *f = fopen(fileName, "r");
    if(f == NULL){
        printf("erro na abertura do arquivo");
        exit(1);
    }
    
    int linhas = 0;
    while(!feof(f)){
        fscanf(f, "%*[^\n]\n");
        linhas++;
    }

    fclose(f);
    return linhas;
}

