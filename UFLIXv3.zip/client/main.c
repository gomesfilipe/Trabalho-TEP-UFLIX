#include "../include/usuario.h"
#include "../include/utils.h"


int main(){
    tFilme **filmes;
    char *fileName = "./data/filmes-pequeno.csv";
    
    filmes = leFilmes(fileName);
    imprimeTodosOsFilmes(filmes, contaLinhasCSV("./data/filmes-pequeno.csv")); 

    return 0;
}