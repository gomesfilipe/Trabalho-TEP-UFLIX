#ifndef FILME_H
#define FILME_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Para funções toupper e tolower

typedef struct filme tFilme;

#endif

