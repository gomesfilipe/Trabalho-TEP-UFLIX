#ifndef USUARIO_H
#define USUARIO_H

#include "historico.h"

typedef struct usuario tUsuario;



#endif