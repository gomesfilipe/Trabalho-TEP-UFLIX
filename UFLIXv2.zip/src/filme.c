#include "../include/filme.h"

struct filme{
    char *titulo; // vetor de caracteres
    char *descricao; // vetor de caracteres
    float nota;
    int duracao;
    int ano;
    int id;
};

// imprimir filme
// listar filmes
// dar nota ao filme 
// pesquisar filmes
// avançar pagina de filmes
// voltar pagina de filmes

//lembrar de fazer comentarios