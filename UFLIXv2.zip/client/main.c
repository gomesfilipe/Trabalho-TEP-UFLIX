#include "../include/usuario.h"

int main(){
    int dia, mes, ano;
    tData *d1, *d2;
    d1 = leData();
    d2 = leData();

    printf("%d\n", datacmp(d1,d2));

    
    
    return 0;
}